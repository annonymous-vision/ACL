import argparse
import os
import pickle
from pathlib import Path

import clip
import numpy as np
import openai
import pandas as pd
import requests
import torch

from model_factory import create_clip
from prompts.gpt4_prompt import create_NIH_prompts, create_RSNA_prompts, create_CELEBA_prompts, \
    create_Waterbirds_prompts, create_Metashift_prompts
from utils import seed_all


def config():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", default="Waterbirds", type=str)
    parser.add_argument("--clip_check_pt", default="", type=str)
    parser.add_argument("--open-ai-key", default="", type=str)
    parser.add_argument("--clip_vision_encoder", default="swin-tiny-cxr-clip", type=str)
    parser.add_argument("--class_label", default="", type=str)
    parser.add_argument("--device", default="cuda", type=str)
    parser.add_argument("--prediction_col", default="out_put_predict", type=str)
    parser.add_argument(
        "--top50-err-text",
        default="source_dir/cvpr_submit/out/NIH_Cxrclip/resnet50/seed0/clip_img_encoder_swin-tiny-cxr-clip/pneumothorax_error_top_50_sent_diff_emb.txt",
        type=str
    )
    parser.add_argument(
        "--save_path", metavar="DIR",
        default="source_dir/cvpr_submit/out/Waterbirds/resnet_sup_in1k_attrNo/Waterbirds_ERM_hparams0_seed0/clip_img_encoder_ViT-B/32",
        help=""
    )
    parser.add_argument(
        "--clf_results_csv", metavar="DIR",
        default="source_dir/cvpr_submit/out/Waterbirds/resnet_sup_in1k_attrNo/Waterbirds_ERM_hparams0_seed0/clip_img_encoder_ViT-B/32/test_additional_info.csv",
        help=""
    )
    parser.add_argument(
        "--clf_image_emb_path", metavar="DIR",
        default="source_dir/cvpr_submit/out/Waterbirds/resnet_sup_in1k_attrNo/Waterbirds_ERM_hparams0_seed0/clip_img_encoder_ViT-B/32/test_classifier_embeddings.npy",
        help=""
    )

    parser.add_argument(
        "--aligner_path", metavar="DIR",
        default="source_dir/cvpr_submit/out/Waterbirds/resnet_sup_in1k_attrNo/Waterbirds_ERM_hparams0_seed0/aligner/aligner_50.pth",
        help=""
    )

    parser.add_argument("--seed", default="0", type=int)

    return parser.parse_args()


def get_hypothesis_from_LLM(open_ai_key, prompt, hypothesis_dict_file, prompt_dict_file):
    openai.api_key = open_ai_key
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {openai.api_key}"
    }

    payload = {
        "model": "gpt-4-turbo",
        "messages": [
            {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": prompt
                    },
                ]
            }
        ],
        "max_tokens": 3000,
        "temperature": 0.5,
        "seed": 42
    }

    response = requests.post("https://api.openai.com/v1/chat/completions", headers=headers, json=payload)
    data = response.json()
    print(data)
    python_code = data['choices'][0]['message']['content']
    clean_python_code = python_code.strip('`').split('python\n')[1]
    local_vars = {}
    exec(clean_python_code, {}, local_vars)

    hypothesis_dict = local_vars['hypothesis_dict']
    prompt_dict = local_vars['prompt_dict']

    pickle.dump(hypothesis_dict, open(hypothesis_dict_file, "wb"))
    pickle.dump(prompt_dict, open(prompt_dict_file, "wb"))

    return hypothesis_dict, prompt_dict


def get_prompt_embedding(hyp_sent_list, clip_model, dataset_type="medical"):
    if dataset_type == "medical":
        attr_embs = []
        with torch.no_grad():
            for prompt in hyp_sent_list:
                print(prompt)
                text_token = clip_model["tokenizer"](
                    prompt, padding="longest", truncation=True, return_tensors="pt", max_length=256
                )
                text_emb = clip_model["model"].encode_text(text_token.to("cuda"))
                text_emb = clip_model["model"].text_projection(text_emb) if clip_model["model"].projection else text_emb
                text_emb = text_emb.mean(dim=0, keepdim=True)
                text_emb /= text_emb.norm(dim=-1, keepdim=True)
                attr_embs.append(text_emb)

        attr_embs = torch.stack(attr_embs).squeeze().detach()
        return attr_embs
    else:
        with torch.no_grad():
            attr_embs = []
            for prompt in hyp_sent_list:
                text_token = clip.tokenize(prompt).to("cuda")
                text_emb = clip_model["model"].encode_text(text_token.to("cuda"))
                text_emb = text_emb.mean(dim=0, keepdim=True)
                text_emb /= text_emb.norm(dim=-1, keepdim=True)
                attr_embs.append(text_emb)

            attr_embs = torch.stack(attr_embs).squeeze().detach().cpu().numpy()
            return attr_embs


def discover_slices(
        df, pred_col, prompt_dict, clip_model, clf_image_emb_path, aligner_path, save_path, save_file,
        dataset_type="medical",
        percentile=75, class_label=1):
    hyp_sent_list = []
    hyp_list = []

    for key, value in prompt_dict.items():
        hyp_list.append(key)
        hyp_sent_list.append(value)

    attr_embs = get_prompt_embedding(hyp_sent_list, clip_model, dataset_type=dataset_type)
    attr_embs = torch.tensor(attr_embs)
    print(f"attr_embs: {attr_embs.size()}")

    print(df.shape)
    df_indx = df.index.tolist()
    img_emb_clf = np.load(clf_image_emb_path)
    print(img_emb_clf.shape)
    img_emb_clf = img_emb_clf[df_indx]

    aligner = torch.load(aligner_path)
    W = aligner["W"]
    b = aligner["b"]

    img_emb_clf_tensor = torch.from_numpy(img_emb_clf)
    img_emb_clip_tensor = img_emb_clf_tensor @ W.T + b
    print(type(img_emb_clip_tensor), type(attr_embs))
    sim_score = torch.matmul(img_emb_clip_tensor.to("cuda").float(), attr_embs.to("cuda").float().T)
    print(f"img_emb_clip_tensor: {img_emb_clip_tensor.size()}")
    print(f"sim_score size: {sim_score.size()}")
    acc = []
    for idx, hyp in enumerate(hyp_list):
        print("==============================================")
        print(idx, hyp)
        df[hyp] = sim_score[:, idx].cpu().numpy()
        pt = df[df["out_put_GT"] == class_label]
        print(pt.shape)
        th = np.percentile(pt[hyp].values, percentile)
        print(th)
        err_slice = pt[pt[hyp] < th]
        print(err_slice.shape)
        gt = err_slice["out_put_GT"].values
        pred = err_slice[pred_col].values
        print(f"Accuracy on the error slice (where attribute absent): {np.mean(gt == pred)}")

        err_slice = pt[pt[hyp] >= th]
        print(err_slice.shape)
        gt = err_slice["out_put_GT"].values
        pred = err_slice[pred_col].values
        print(f"Accuracy on the bias aligned slice (where attribute present): {np.mean(gt == pred)}")
        acc.append(np.mean(gt == pred))

        df[f"{hyp}_bin"] = (df[hyp].values >= th).astype(int)
        print("==============================================")

    print(f"Mean accuracy on all the error slices: {np.mean(acc)}\n")
    print(df.head(10))
    df.to_csv(save_path / save_file, index=False)


def validate_error_slices_via_LLM(
        open_ai_key, save_path, clf_results_csv, clf_image_emb_path, aligner_path,
        prompt, clip_model, prediction_col, datase_type="medical", mode="valid", class_label="", percentile=75):
    df = pd.read_csv(clf_results_csv)
    if prediction_col == "out_put_predict":
        df['Predictions_bin'] = (df[prediction_col] >= 0.5).astype(int)
        pred_col = "Predictions_bin"
    else:
        pred_col = prediction_col
    print(f"Prediction column: {pred_col}")
    print(f"\ndf: {df.shape}")

    print("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Prompt start >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
    print(prompt)
    print("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Prompt End >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")

    hypothesis_dict_file = save_path / f"{class_label}_hypothesis_dict.pkl"
    prompt_dict_file = save_path / f"{class_label}_prompt_dict.pkl"
    if hypothesis_dict_file.exists() and prompt_dict_file.exists():
        hypothesis_dict = pickle.load(open(hypothesis_dict_file, "rb"))
        prompt_dict = pickle.load(open(prompt_dict_file, "rb"))
    else:
        hypothesis_dict, prompt_dict = get_hypothesis_from_LLM(
            open_ai_key, prompt, hypothesis_dict_file, prompt_dict_file)

    print("<<<<<====================================================>>>>")
    print("Hypothesis Dictionary:")
    print(hypothesis_dict)
    print("\nPrompt Dictionary:")
    print(prompt_dict)
    print("<<<<<====================================================>>>>")
    if class_label.lower() == "landbirds" or class_label.lower() == "dog":
        class_idx = 0
    else:
        class_idx = 1
    print(f"class_label (class_idx): {class_label} ({class_idx})")
    discover_slices(
        df, pred_col, prompt_dict, clip_model, clf_image_emb_path, aligner_path, save_path,
        save_file=f"{mode}_{class_label}_dataframe_mitigation.csv", dataset_type=datase_type, percentile=percentile,
        class_label=class_idx)


def validate_error_slices_via_sent(
        open_ai_key, dataset, save_path, clf_results_csv, clf_image_emb_path, aligner_path,
        top50_err_text, clip_model, class_label, prediction_col, mode="test"):
    with open(top50_err_text, "r") as file:
        content = file.read()
    if dataset.lower() == "nih":
        prompt = create_NIH_prompts(content)
        validate_error_slices_via_LLM(
            open_ai_key, save_path, clf_results_csv, clf_image_emb_path, aligner_path, prompt,
            clip_model, prediction_col, datase_type="medical", mode=mode, class_label=class_label, percentile=55
        )
    elif dataset.lower() == "rsna":
        prompt = create_RSNA_prompts(content)
        validate_error_slices_via_LLM(
            open_ai_key, save_path, clf_results_csv, clf_image_emb_path, aligner_path, prompt,
            clip_model, prediction_col, datase_type="medical", mode=mode, class_label=class_label, percentile=40
        )
    elif dataset.lower() == "celeba":
        prompt = create_CELEBA_prompts(content)
        validate_error_slices_via_LLM(
            open_ai_key, save_path, clf_results_csv, clf_image_emb_path, aligner_path, prompt,
            clip_model, prediction_col, datase_type="vision", mode=mode, class_label=class_label, percentile=50
        )
    elif dataset.lower() == "waterbirds":
        prompt = create_Waterbirds_prompts(content)
        validate_error_slices_via_LLM(
            open_ai_key, save_path, clf_results_csv, clf_image_emb_path, aligner_path, prompt,
            clip_model, prediction_col, datase_type="vision", mode=mode, class_label=class_label, percentile=55
        )
    elif dataset.lower() == "metashift":
        cat_prompt, dog_prompt = create_Metashift_prompts(content)
        prompt = None
        if class_label.lower() == "cat":
            prompt = cat_prompt
        elif class_label.lower() == "dog":
            prompt = dog_prompt

        validate_error_slices_via_LLM(
            open_ai_key, save_path, clf_results_csv, clf_image_emb_path, aligner_path, prompt,
            clip_model, prediction_col, datase_type="vision", mode=mode, class_label=class_label, percentile=55
        )


def main(args):
    seed_all(args.seed)
    os.environ["TOKENIZERS_PARALLELISM"] = "false"
    args.aligner_path = args.aligner_path.format(args.seed)
    args.top50_err_text = args.top50_err_text.format(args.seed)
    args.save_path = Path(args.save_path.format(args.seed))
    args.save_path.mkdir(parents=True, exist_ok=True)
    clip_model = create_clip(args)

    print("####################" * 10)
    if args.prediction_col == "out_put_predict":
        clf_results_csv = args.clf_results_csv.format(args.seed, "valid")
        clf_image_emb_path = args.clf_image_emb_path.format(args.seed, "valid")
        print("####################" * 10)
        print("=======================================>>>>> Mode: Valid <<<<<=======================================")
        validate_error_slices_via_sent(
            args.open_ai_key, args.dataset, args.save_path, clf_results_csv, clf_image_emb_path, args.aligner_path,
            args.top50_err_text, clip_model, args.class_label, args.prediction_col, mode="valid"
        )

        clf_results_csv = args.clf_results_csv.format(args.seed, "test")
        clf_image_emb_path = args.clf_image_emb_path.format(args.seed, "test")
        print("\n")
        print(args.save_path)
        print("####################" * 10)
        print("=======================================>>>>> Mode: Test <<<<<=======================================")
        validate_error_slices_via_sent(
            args.open_ai_key, args.dataset, args.save_path, clf_results_csv, clf_image_emb_path, args.aligner_path,
            args.top50_err_text, clip_model, args.class_label, args.prediction_col, mode="test"
        )

        clf_results_csv = args.clf_results_csv.format(args.seed, "train")
        clf_image_emb_path = args.clf_image_emb_path.format(args.seed, "train")
        print("\n")
        print(args.save_path)
        print("####################" * 10)
        print("=======================================>>>>> Mode: Train <<<<<=======================================")
        validate_error_slices_via_sent(
            args.open_ai_key, args.dataset, args.save_path, clf_results_csv, clf_image_emb_path, args.aligner_path,
            args.top50_err_text, clip_model, args.class_label, args.prediction_col, mode="train"
        )
    else:
        # clf_results_csv = args.clf_results_csv.format(args.seed)
        # clf_image_emb_path = args.clf_image_emb_path.format(args.seed, "valid")
        # print("####################" * 10)
        # print("=======================================>>>>> Mode: Valid <<<<<=======================================")
        # validate_error_slices_via_sent(
        #     args.open_ai_key, args.dataset, args.save_path, clf_results_csv, clf_image_emb_path, args.aligner_path,
        #     args.top50_err_text, clip_model, args.class_label, args.prediction_col, mode="valid"
        # )

        clf_results_csv = args.clf_results_csv.format(args.seed, "test")
        clf_image_emb_path = args.clf_image_emb_path.format(args.seed, "test")
        print("\n")
        print(args.save_path)
        print("####################" * 10)
        print("=======================================>>>>> Mode: Test <<<<<=======================================")
        validate_error_slices_via_sent(
            args.open_ai_key, args.dataset, args.save_path, clf_results_csv, clf_image_emb_path, args.aligner_path,
            args.top50_err_text, clip_model, args.class_label, args.prediction_col, mode="test"
        )


if __name__ == "__main__":
    _args = config()
    main(_args)
